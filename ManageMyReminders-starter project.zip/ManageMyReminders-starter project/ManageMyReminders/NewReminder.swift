//
//  NewReminder.swift
//  ManageMyReminders
//
//  Created by Malek T. on 11/20/15.
//  Copyright © 2015 Medigarage Studios LTD. All rights reserved.
//

import UIKit
import SQLite3

class NewReminder: UIViewController {

    class Transfert {
        var list: String
//        var imageR: String
        
        init(list: String) {
            
            self.list = list
//            self.imageR = image
        }
    }
    
    var db : OpaquePointer?
    var TransfertList = [Transfert]()
   
    @IBOutlet weak var listName: UITextField!
    
    @IBOutlet weak var image: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let fileURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false).appendingPathComponent("Database.sqlite")
                  
                  if sqlite3_open(fileURL.path, &db) != SQLITE_OK {
                      print("error opening database")
                  }
                  
                  if sqlite3_exec(db, "CREATE TABLE IF NOT EXISTS Transfert (list TEXT PRIMARY KEY)", nil, nil, nil) != SQLITE_OK {
                      let errmsg = String(cString: sqlite3_errmsg(db)!)
                      print("error creating table: \(errmsg)")
                  }
                  
                  readValues()
    }
    @IBAction func saveNewReminder(sender: AnyObject) {
        let name = listName.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        if(name?.isEmpty)!{
            listName.layer.borderColor = UIColor.red.cgColor
            return
        }
        var stmt: OpaquePointer?
        
        let queryString = "INSERT INTO Transfert (list) VALUES (?)"
        
        if sqlite3_prepare(db, queryString, -1, &stmt, nil) != SQLITE_OK{
                     let errmsg = String(cString: sqlite3_errmsg(db)!)
                     print("error preparing insert: \(errmsg)")
                     return
                 }

                 if sqlite3_bind_text(stmt, 1, name, -1, nil) != SQLITE_OK{
                     let errmsg = String(cString: sqlite3_errmsg(db)!)
                     print("failure binding name: \(errmsg)")
                     return
                 }
        
        if sqlite3_step(stmt) != SQLITE_DONE {
                       let errmsg = String(cString: sqlite3_errmsg(db)!)
                       print("failure inserting hero: \(errmsg)")
                       return
                   }
        listName.text = ""
//        image.image = UIImage(named: "reminder-4")
        
        readValues()
        print("salavto")
        
    }
    
    @IBOutlet weak var saveB: UIBarButtonItem!
    func readValues(){
             TransfertList.removeAll()

             let queryString = "SELECT * FROM Transfert"
             
             var stmt:OpaquePointer?
             
             if sqlite3_prepare(db, queryString, -1, &stmt, nil) != SQLITE_OK{
                 let errmsg = String(cString: sqlite3_errmsg(db)!)
                 print("error preparing insert: \(errmsg)")
                 return
             }
             
             while(sqlite3_step(stmt) == SQLITE_ROW){
                 let name = String(cString: sqlite3_column_text(stmt, 0))
                 
                TransfertList.append(Transfert( list: name))
             }
       
        self.dismiss(animated: false, completion: nil)
         }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func dismiss(sender: AnyObject) {
        
         self.dismiss(animated: false, completion: nil)
    }
    /*
    import UIKit
    import SQLite3

    class ViewController: UIViewController {
        
        var db: OpaquePointer?
        var TransfertList = [Transfert]()
        
        @IBOutlet weak var descrField: UITextField!
        @IBOutlet weak var valoreField: UITextField!
        @IBOutlet weak var tipoField: UITextField!
        @IBOutlet weak var modField: UITextField!
        
        @IBAction func buttonSave(_ sender: UIButton) {
            var stmt: OpaquePointer?
            
            let queryString = "INSERT INTO Transfert (name, valore, tipo, mod) VALUES (?,?,?,?)"
            
            if sqlite3_prepare(db, queryString, -1, &stmt, nil) != SQLITE_OK{
                let errmsg = String(cString: sqlite3_errmsg(db)!)
                print("error preparing insert: \(errmsg)")
                return
            }

            if sqlite3_bind_text(stmt, 1, name, -1, nil) != SQLITE_OK{
                let errmsg = String(cString: sqlite3_errmsg(db)!)
                print("failure binding name: \(errmsg)")
                return
            }
            
            if sqlite3_bind_text(stmt, 1, valore, -1, nil) != SQLITE_OK{
                let errmsg = String(cString: sqlite3_errmsg(db)!)
                print("failure binding name: \(errmsg)")
                return
            }
            
            if sqlite3_bind_text(stmt, 1, tipo, -1, nil) != SQLITE_OK{
                let errmsg = String(cString: sqlite3_errmsg(db)!)
                print("failure binding name: \(errmsg)")
                return
            }
            
            if sqlite3_bind_text(stmt, 1, mod, -1, nil) != SQLITE_OK{
                let errmsg = String(cString: sqlite3_errmsg(db)!)
                print("failure binding name: \(errmsg)")
                return
            }

            if sqlite3_step(stmt) != SQLITE_DONE {
                let errmsg = String(cString: sqlite3_errmsg(db)!)
                print("failure inserting hero: \(errmsg)")
                return
            }
            
            descrField.text=""
            valoreField.text=""
            tipoField.text=""
            modField.text=""
            
            readValues()

            print("Herro saved successfully")
        }
        
        
        func readValues(){
            TransfertList.removeAll()

            let queryString = "SELECT * FROM Transfert"
            
            var stmt:OpaquePointer?
            
            if sqlite3_prepare(db, queryString, -1, &stmt, nil) != SQLITE_OK{
                let errmsg = String(cString: sqlite3_errmsg(db)!)
                print("error preparing insert: \(errmsg)")
                return
            }
            
            while(sqlite3_step(stmt) == SQLITE_ROW){
                let id = sqlite3_column_int(stmt, 0)
                let name = String(cString: sqlite3_column_text(stmt, 1))
                
                TransfertList.append(Transfert(id: Int(id), descrizione: name, valore: 1, tipo: "ciao", modalita: "ciao"))
            }
      
            for i in 0...TransfertList.count-1{
                print(TransfertList

    [i].descrizione)
            }
            
        }
        
        override func viewDidLoad() {
            super.viewDidLoad()
        
            let fileURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false).appendingPathComponent("Database.sqlite")
            
            if sqlite3_open(fileURL.path, &db) != SQLITE_OK {
                print("error opening database")
            }
            
            if sqlite3_exec(db, "CREATE TABLE IF NOT EXISTS Transfert (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, valore INTEGER, tipo TEXT, mod TEXT)", nil, nil, nil) != SQLITE_OK {
                let errmsg = String(cString: sqlite3_errmsg(db)!)
                print("error creating table: \(errmsg)")
            }
            
            readValues()
        }
    }
    */
}
