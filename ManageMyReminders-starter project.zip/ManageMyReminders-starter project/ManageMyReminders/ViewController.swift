//
//  ViewController.swift
//  ManageMyReminders
//
//  Created by Malek T. on 11/19/15.
//  Copyright © 2015 Medigarage Studios LTD. All rights reserved.
//
import SQLite3
import UIKit


class ViewController: UIViewController,UITableViewDataSource, UITableViewDelegate{
    
    class Transfert {
        var list: String
          
          
          init(list: String) {
              
              self.list = list
              
          }
      }
    
    var db: OpaquePointer?
    var TransfertList = [Transfert]()
    var TransfertListFilter = [Transfert]()
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return TransfertList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") as? TableCell else {
            return UITableViewCell()
        }
        
       cell.reminderName.text = TransfertList[indexPath.row].list
        
        return cell
    }
    

    @IBOutlet var tableView: UITableView!
    
    override func viewWillAppear(_ animated: Bool) {
       
    }
    
    override func viewDidAppear(_ animated: Bool) {
         readValues()
        tableView.reloadData()
               
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.automaticallyAdjustsScrollViewInsets = false
        self.view.backgroundColor = .darkGray
        
             let fileURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false).appendingPathComponent("Database.sqlite")
                        
                if sqlite3_open(fileURL.path, &db) != SQLITE_OK {
                    print("error opening database")
                    return
                }
                /*
               if sqlite3_exec(db, "DROP TABLE Transfert", nil, nil, nil) != SQLITE_OK {
                          let errmsg = String(cString: sqlite3_errmsg(db)!)
                             print("error creating table: \(errmsg)")
//
                    }*/
        //
        //        if sqlite3_exec(db, "CREATE TABLE IF NOT EXISTS Transfert (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, valore TEXT, tipo TEXT, mod TEXT)", nil, nil, nil) != SQLITE_OK {
        //            let errmsg = String(cString: sqlite3_errmsg(db)!)
        //            print("error creating table: \(errmsg)")
//                  return
        //        }
        
        
        
                readValues();
//                setUpSearchBar()
                alterLayout()
    
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }

    @IBAction func editTable(sender: AnyObject) {
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func alterLayout() {
          tableView.tableHeaderView = UIView()
          tableView.estimatedSectionHeaderHeight = 50
//          navigationItem.titleView = searchBar
//          searchBar.showsScopeBar = false
//          searchBar.placeholder = "Search Animal by Name"
      }
    
      
        func readValues(){
            TransfertList.removeAll()

            let queryString = "SELECT * FROM Transfert"
              
            var stmt:OpaquePointer?
              
            if sqlite3_prepare(db, queryString, -1, &stmt, nil) != SQLITE_OK{
                let errmsg = String(cString: sqlite3_errmsg(db)!)
                print("error preparing insert: \(errmsg)")
                return
            }
              
            while(sqlite3_step(stmt) == SQLITE_ROW){
                
                let d = String(cString: sqlite3_column_text(stmt, 0))
                
                  
                TransfertList.append(Transfert( list: d))
            }
        
          
//                print(TransfertList[0].list)
            
        }
    
}

/*
 import UIKit
 import SQLite3

 class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UISearchBarDelegate {
     
     @IBOutlet var table: UITableView!
     @IBOutlet var searchBar: UISearchBar!
     
    class Transfert {
         var id: Int
         var descrizione: String
         var valore: String
         var tipo: String
         var modalita: String
         
         init(id: Int, descrizione: String, valore: String, tipo: String, modalita: String){
             self.id = id
             self.descrizione = descrizione
             self.valore = valore
             self.tipo = tipo
             self.modalita = modalita
         }
     }
     
     var db: OpaquePointer?
     var TransfertList = [Transfert]()
     var TransfertListFilter = [Transfert]()
     
     override func viewDidLoad() {
         super.viewDidLoad()
         
         let fileURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false).appendingPathComponent("Database.sqlite")
                 
         if sqlite3_open(fileURL.path, &db) != SQLITE_OK {
             print("error opening database")
         }
         
 //        if sqlite3_exec(db, "DROP TABLE Transfert", nil, nil, nil) != SQLITE_OK {
 //                     let errmsg = String(cString: sqlite3_errmsg(db)!)
 //                     print("error creating table: \(errmsg)")
 //            }
 //
 //        if sqlite3_exec(db, "CREATE TABLE IF NOT EXISTS Transfert (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, valore TEXT, tipo TEXT, mod TEXT)", nil, nil, nil) != SQLITE_OK {
 //            let errmsg = String(cString: sqlite3_errmsg(db)!)
 //            print("error creating table: \(errmsg)")
 //        }
         
         readValues();
         setUpSearchBar()
         alterLayout()
     }
     
     func readValues(){
         TransfertList.removeAll()

         let queryString = "SELECT * FROM Transfert"
           
         var stmt:OpaquePointer?
           
         if sqlite3_prepare(db, queryString, -1, &stmt, nil) != SQLITE_OK{
             let errmsg = String(cString: sqlite3_errmsg(db)!)
             print("error preparing insert: \(errmsg)")
             return
         }
           
         while(sqlite3_step(stmt) == SQLITE_ROW){
             let id = sqlite3_column_int(stmt, 0)
             let d = String(cString: sqlite3_column_text(stmt, 1))
             let v = String(cString: sqlite3_column_text(stmt, 2))
             let t = String(cString: sqlite3_column_text(stmt, 3))
             let m = String(cString: sqlite3_column_text(stmt, 4))
               
             TransfertList.append(Transfert(id: Int(id), descrizione: d, valore: v, tipo: t, modalita: m))
         }
     
 //        for i in 0...TransfertList.count-1{
 //            print(TransfertList[i].descrizione)
 //        }
     }

     private func setUpSearchBar() {
         searchBar.delegate = self
     }

     func alterLayout() {
         table.tableHeaderView = UIView()
         table.estimatedSectionHeaderHeight = 50
         navigationItem.titleView = searchBar
         searchBar.showsScopeBar = false
         searchBar.placeholder = "Search Animal by Name"
     }

     // Table
     func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
         return TransfertList.count
     }

     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
         guard let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") as? TableCell else {
             return UITableViewCell()
         }
         
         cell.descriLabel.text = TransfertList[indexPath.row].descrizione
         cell.modLabel.text = TransfertList[indexPath.row].modalita
         cell.tipoLabel.text = TransfertList[indexPath.row].tipo
         cell.valLabel.text = String(TransfertList[indexPath.row].valore)

         return cell
     }

     func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
         return 100
     }

     // Search Bar
     func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {

 TransfertListFilter = TransfertList.filter({ Transfert -> Bool in
             switch searchBar.selectedScopeButtonIndex {
             case 0:
                 if searchText.isEmpty { return true }
                 return Transfert.descrizione.lowercased().contains(searchText.lowercased())
             default:
                 return false
             }
         })
         table.reloadData()
     }

     func searchBar(_ searchBar: UISearchBar, selectedScopeButtonIndexDidChange selectedScope: Int) {
         switch selectedScope {
         case 0:
             TransfertList = TransfertListFilter
         default:
             break
         }
         table.reloadData()
     }
 }
 */
