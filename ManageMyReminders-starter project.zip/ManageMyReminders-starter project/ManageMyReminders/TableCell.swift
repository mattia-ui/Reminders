//
//  TableCell.swift
//  ManageMyReminders
//
//  Created by Mattia Cardone on 09/12/2019.
//  Copyright © 2019 Medigarage Studios LTD. All rights reserved.
//

import UIKit

class TableCell : UITableViewCell {
    
    @IBOutlet weak var reminderImage: UIImageView!
    @IBOutlet weak var reminderName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
}
