//
//  ReminderDetails.swift
//  ManageMyReminders
//
//  Created by Malek T. on 11/20/15.
//  Copyright © 2015 Medigarage Studios LTD. All rights reserved.
//

import UIKit
/*
class ReminderDetails: UIViewController,UITableViewDataSource, UITableViewDelegate, UISearchBarDelegate {
   
    class Transfert {
        var list: String
          
          
          init(list: String) {
              
              self.list = list
              
          }
      }
    
    var db: OpaquePointer?
    var TransfertList = [Transfert]()
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return TransfertList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") as? TableCell else {
             return UITableViewCell()
         }
         
        cell.reminderName.text = TransfertList[indexPath.row].list
         
         return cell
    }
    

    @IBOutlet weak var reminderName: UILabel!
    
    @IBAction func saveReminder(sender: AnyObject) {
        
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
}
*/
