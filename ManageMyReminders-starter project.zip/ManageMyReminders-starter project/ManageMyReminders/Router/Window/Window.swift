protocol Window: class {
    var rootView: ViewController? { get set }
}
